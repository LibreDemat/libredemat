import grails.util.GrailsUtil
import org.codehaus.groovy.grails.commons.ConfigurationHolder

class LibredematCasclientGrailsPlugin {
    def version = 0.3
    def dependsOn = [:]
    def author = 'Benoit Orihuela'
    def authorEmail = 'bor@zenexity.fr'
    def title = 'This plugin provides client integration for LibreDemat\'s JA-SIG CAS version'

    def doWithSpring = {
        // nothing to do with spring here.
    }
    def doWithApplicationContext = { applicationContext ->
        // nothing to do with application context here.
    }
    def doWithWebDescriptor = { xml ->

        if (ConfigurationHolder.config.cas_mocking) {
            System.out.println('CAS CLIENT PLUGIN INFO: the plugin is mocked therefore nothing needs to be done here.')
            System.out.println('CAS CLIENT PLUGIN INFO: /cas.gsp?login=LOGIN is available for mocking cas-ified user session')
            System.out.println('CAS CLIENT PLUGIN WARNING: Please take extra care as mocking should NOT be allowed for production environment!')
        } else {

            def failed = false

            // to check configurations for filter and its mapping.
            if (ConfigurationHolder.config.cas_login_url instanceof ConfigObject
                || ConfigurationHolder.config.cas_validate_url instanceof ConfigObject
                || ConfigurationHolder.config.cas_url_pattern instanceof ConfigObject) {
                System.err.println('CAS CLIENT PLUGIN ERROR: Please make sure that required parameters [cas_login_url, cas_validate_url, cas_url_pattern] are set up correctly in Config.groovy of your application!')
                failed = true
            }
            else if (ConfigurationHolder.config.cas_server_names instanceof ConfigObject) {
                System.err.println('CAS CLIENT PLUGIN ERROR: Please make sure that one of required parameters [cas_server_names] is set up correctly in Config.groovy of your application!')
                failed = true
            }
            else {

                // to define name of the filter.
                def fname = 'CAS-Filter'

                // to add cas filter.
                def filters = xml.'filter'

                filters[0] + {
                    'filter' {
                        'filter-name' (fname)
                        'filter-class' ('org.libredemat.util.web.filter.CASFilter')
                        'init-param' {
                            'param-name' ('edu.yale.its.tp.cas.client.filter.loginUrl')
                            'param-value' ("${ConfigurationHolder.config.cas_login_url}")
                        }
                        'init-param' {
                            'param-name' ('edu.yale.its.tp.cas.client.filter.validateUrl')
                            'param-value' ("${ConfigurationHolder.config.cas_validate_url}")
                        }

                        if (ConfigurationHolder.config.cas_server_names instanceof String) {
                            'init-param' {
                                'param-name' ('edu.yale.its.tp.cas.client.filter.serverName')
                                'param-value' ("${ConfigurationHolder.config.cas_server_names}")
                            }
                        }
                    }
                }

                System.out.println('CAS CLIENT PLUGIN INFO: added <filter/> section in web.xml')

                // to add cas filter mapping.
                def filtermappings = xml.'filter-mapping'

                if (ConfigurationHolder.config.cas_url_pattern instanceof String) {

                    filtermappings[0] + {
                        'filter-mapping' {
                            'filter-name' (fname)
                            'url-pattern' ("${ConfigurationHolder.config.cas_url_pattern}")
                        }
                    }
                    System.out.println('CAS CLIENT PLUGIN INFO: added <filter-mapping/> section(s) in web.xml')
                } else if (ConfigurationHolder.config.cas_url_pattern instanceof java.util.List) {

                    ConfigurationHolder.config.cas_url_pattern.each { u ->
                        filtermappings[0] + {
                            'filter-mapping' {
                                'filter-name' (fname)
                                'url-pattern' ("${u}")
                            }
                        }
                    }
                    System.out.println('CAS CLIENT PLUGIN INFO: added <filter-mapping/> section(s) in web.xml')
                }
                else {
                    System.err.println('CAS CLIENT PLUGIN ERROR: Please make sure that required parameter [cas_url_pattern] is an instance of either java.lang.String or java.util.List in Config.groovy of your application!')
                    failed = true
                }

                if (failed) {
                	System.out.println("PLEASE CORRECT THE ERROR ABOVE!")
                }

            }
        }
    }

    def doWithDynamicMethods = { ctx ->
        // nothing to do with dynamic methods here.
    }
    def onChange = { event ->
        // no interests in dynamic loading.
    }
    def onApplicationChange = { event ->
        // no interests in dynamic loading.
    }
}
